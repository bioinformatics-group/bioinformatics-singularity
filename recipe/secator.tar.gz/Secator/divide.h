/**************************************/
/*                                    */
/*Clustering par divisions successives*/
/*                                    */
/**************************************/

void divide(int nbIndividus,int nbDimensions,int *nbClusters,individu_t **individus,
	    int typeDonnees,int clusteringMethod,int nbClustersSelection,
	    int donneesNormalisees,int typeDensite,int nbVoisins);
     
